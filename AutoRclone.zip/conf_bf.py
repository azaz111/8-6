osn_serv=5 # от
osn_lim=10 # До

start_json=5  # от
lim_json=10  # До